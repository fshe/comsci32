#ifndef _STUDENTWORLD_H_
#define _STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"

// Students:  Add code to this file, StudentWorld.cpp, actor.h, and actor.cpp

class StudentWorld : public GameWorld
{
public:

	virtual void init()
    {
    }

	virtual int move()
    {
          // This code is here merely to allow the game to build, run, and terminate after hitting enter a few times 
        decLives();
        return GWSTATUS_PLAYER_DIED;
    }

	virtual void cleanUp()
    {
    }

private:
};

#endif // _GAMEWORLD_H_
