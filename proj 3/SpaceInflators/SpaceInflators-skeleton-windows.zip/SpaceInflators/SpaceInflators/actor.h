#ifndef _ACTOR_H_
#define _ACTOR_H_

#include "GraphObject.h"

// Students:  Add code to this file, actor.cpp, StudentWorld.h, and StudentWorld.cpp

#endif // _ACTOR_H_